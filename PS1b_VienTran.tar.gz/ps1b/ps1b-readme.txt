/**********************************************************************
 *  LFSR - PhotoMagic (part B) ps1b-readme.txt
 **********************************************************************/

Name: Vien Tran
Hours to complete assignment: About 2-3 Hours
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
- The program read 3 arguments from the command line, use SFML to load 
the source image from disk and display it in its own windows, use the 
debugged FibLFSR class to encode(or decode) the image, display the 
encoded/decoded image in its own windows and save the new image to disk.
- All of those was accomplished.

/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
- None Received

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
- None

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
- The decode.png has a picture of another entity which has granted 
permission for the picture to be used in this program.